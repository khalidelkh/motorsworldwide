======= Indusri Plus =====

Indusri Plus plugin adds additonal features for Indusri theme.


== Changelog ==

= 1.0.0 =

    * First release!