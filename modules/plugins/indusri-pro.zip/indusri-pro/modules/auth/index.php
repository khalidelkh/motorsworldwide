<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'IndusriProAuth' ) ) {

	class IndusriProAuth {
		
		private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
			add_filter ( 'theme_page_templates', array( $this, 'indusri_auth_template_attribute' ) );
			add_filter ( 'template_include', array( $this, 'indusri_registration_template' ) );

			$this->load_modules();
			$this->frontend();

			add_action('wp_ajax_indusri_pro_register_user_front_end', array( $this, 'indusri_pro_register_user_front_end', 0 ) );
			add_action('wp_ajax_nopriv_indusri_pro_register_user_front_end', array( $this, 'indusri_pro_register_user_front_end' ) );

			add_action('user_register', array( $this, 'indusri_pro_registration_mail' ) );
        }

		/**
		 * Add Custom Templates to page template array
		*/
		function indusri_auth_template_attribute($templates) {
			$templates = array_merge($templates, array(
				'tpl-registration.php' => esc_html__('Registration Page Template', 'indusri-pro') ,
			));
			return $templates;
		}

		/**
		 * Include Custom Templates page from plugin
		*/
		function indusri_registration_template($template){

			global $post;
			$id = $post->ID;
			$file = get_post_meta($post->ID, '_wp_page_template', true);
			if ('tpl-registration.php' == $file){
				$template = INDUSRI_PRO_DIR_PATH . 'modules/auth/templates/tpl-registration.php';
			}
			return $template;

		}

		function load_modules() {
			include_once INDUSRI_PRO_DIR_PATH.'modules/auth/customizer/index.php';
		}

		function frontend() {
			add_action( 'indusri_after_main_css', array( $this, 'enqueue_css_assets' ), 30 );
			add_action( 'indusri_before_enqueue_js', array( $this, 'enqueue_js_assets' ) );
		}

		function enqueue_css_assets() {
			wp_enqueue_style( 'indusri-pro-auth', INDUSRI_PRO_DIR_URL . 'modules/auth/assets/css/style.css', false, INDUSRI_PRO_VERSION, 'all');
		}

		function enqueue_js_assets() {
			wp_enqueue_script( 'indusri-pro-auth', INDUSRI_PRO_DIR_URL . 'modules/auth/assets/js/script.js', array(), INDUSRI_PRO_VERSION, true );
		}

		/**
		 * User Registration Save Data
		 */

		function indusri_pro_register_user_front_end() {

			$first_name = isset( $_POST['first_name'] ) ? indusri_sanitization($_POST['first_name']) : '';
			$last_name  = isset( $_POST['last_name'] )  ? indusri_sanitization($_POST['last_name'])  : '';
			$password   = isset( $_POST['password'] )   ? indusri_sanitization($_POST['password'] )  : '';
			$user_name  = isset( $_POST['user_name'] )  ? indusri_sanitization($_POST['user_name'])  : '';
			$user_email = isset( $_POST['user_email'] ) ? indusri_sanitization($_POST['user_email']) : '';

			$user = array(
				'user_login'  =>  $user_name,
				'user_email'  =>  $user_email,
				'user_pass'   =>  $password,
				'first_name'  =>  $first_name,
				'last_name'   =>  $last_name
			);

			$result = wp_insert_user( $user );
			if (!is_wp_error($result)) {
					echo 'We have Created an account for you.';
					indusri_pro_registration_mail($user_id);
			} else {
				if (isset($result->errors['empty_user_login']) &&  (isset($result->errors['empty_user_email']))){
					echo 'User Name and Email are required';
				} elseif (isset($result->errors['existing_user_login'])) {
					echo 'User name already exixts.';
				} else {
					echo 'Something Went Wrong.';
				}
			}

		}
		
		function indusri_pro_registration_mail($user_id , $user_name , $password ) {

			$indusri_pro_user = get_userdata($user_id);
			$indusri_pro_user_email = $indusri_pro_user->indusri_pro_user_email;

			// email will send registers
			$indusri_pro_to = $indusri_pro_user_email;
			$indusri_pro_subject = "Hi";
			$indusri_pro_body = '
						<p>
						We have successfully registered you as a Student.
						Username ='.$user_name.';
						Password ='.$password .';
						</p>
			';
			$indusri_pro_headers = array('Content-Type: text/html; charset=UTF-8');
			wp_mail($indusri_pro_to, $indusri_pro_subject, $indusri_pro_body, $indusri_pro_headers);

		}

	}

	add_action( 'wp_ajax_indusri_pro_show_login_form_popup', 'indusri_pro_show_login_form_popup' );
	add_action( 'wp_ajax_nopriv_indusri_pro_show_login_form_popup', 'indusri_pro_show_login_form_popup' );
	function indusri_pro_show_login_form_popup() {
		echo indusri_pro_login_form();

		die();
	}

	// Login form
	if(!function_exists('indusri_pro_login_form')) {
		function indusri_pro_login_form() {

			$out = '<div class="indusri-pro-login-form-container">';

				$out .= '<div class="indusri-pro-login-form">';

					$out .= '<div class="indusri-pro-login-form-holder">';

					$my_login_args = apply_filters( 'login_form_defaults', array(
						'echo'           => false,
						'redirect'       => site_url( $_SERVER['REQUEST_URI'] ), 
						'form_id'        => 'loginform',
						'label_username' => '',
						'label_password' => '',
						'label_remember' => esc_html__( 'Remember Me' ),
						'label_log_in'   => esc_html__( 'Sign In' ),
						'id_username'    => 'user_login',
						'id_password'    => 'user_pass',
						'id_remember'    => 'rememberme',
						'id_submit'      => 'wp-submit',
						'remember'       => true,
						'value_username' => NULL,
						'value_remember' => false
					) );

					$out .= '<div class="indusri-pro-title-logo indusri-pro-login-logo">';
						$out .= '<div class="login-form-custom-logo">'; 
							$out .= '<img class="pre_loader_image" alt="'.esc_attr( get_bloginfo( 'name', 'display' ) ).'" src="'.indusri_customizer_settings('enable_auth_logo').'"/>';
						$out .= '</div>';

						$out .= '<div class="login-form-description">';
							$out .= '<span class="indusri-pro-login-description">'.esc_html__('Please enter your valid login details.', 'indusri-pro').'</span>';
						$out .= '</div>';

						$out .= wp_login_form( $my_login_args );
						$out .= '<p class="tpl-forget-pwd"><a href="'.wp_lostpassword_url( get_permalink() ).'">'.esc_html__('Forgot password ?','indusri-pro').'</a></p>';

					$out .= '</div>';

					$social_logins = (indusri_customizer_settings( 'enable_social_logins' ) !== null) && !empty(indusri_customizer_settings( 'enable_social_logins' )) ? indusri_customizer_settings( 'enable_social_logins' ) : 0;
					$enable_facebook_login = (indusri_customizer_settings( 'enable_facebook_login' ) !== null) && !empty(indusri_customizer_settings( 'enable_facebook_login' )) ? indusri_customizer_settings( 'enable_facebook_login' ) : 0;
					$facebook_app_id = (indusri_customizer_settings( 'facebook_app_id' ) !== null) && !empty(indusri_customizer_settings( 'facebook_app_id' )) ? indusri_customizer_settings( 'facebook_app_id' ) : '';
					$facebook_app_secret = (indusri_customizer_settings( 'facebook_app_secret' ) !== null) && !empty(indusri_customizer_settings( 'facebook_app_secret' )) ? indusri_customizer_settings( 'facebook_app_secret' ) : '';
					$enable_google_login = (indusri_customizer_settings( 'enable_google_login' ) !== null) && !empty( indusri_customizer_settings( 'enable_google_login' ) ) ? indusri_customizer_settings( 'enable_google_login' ) : 0;

					if( $social_logins ) {
						if( $enable_facebook_login || $enable_google_login ) {
							$out .= '<div class="indusri-pro-social-logins-container">';
								$out .= '<div class="indusri-pro-social-logins-divider">'.esc_html__('Or Login With', 'indusri-pro').'</div>';
								if($enable_facebook_login) {
									if(!session_id()) {
										session_start();
									}

									include_once INDUSRI_PRO_DIR_PATH.'modules/auth/apis/facebook/Facebook/autoload.php';

									$appId     = $facebook_app_id; //Facebook App ID
									$appSecret = $facebook_app_secret; // Facebook App Secret
	
									$fb = new Facebook\Facebook([
										'app_id' => $appId,
										'app_secret' => $appSecret,
										'default_graph_version' => 'v2.10',
									]);
	
									$helper = $fb->getRedirectLoginHelper();
									$permissions = ['email'];
									$loginUrl = $helper->getLoginUrl( site_url('wp-login.php') . '?dtLMSFacebookLogin=1', $permissions);
	
									$out .= '<a href="'.htmlspecialchars($loginUrl).'" class="indusri-pro-social-facebook-connect"><i class="fab fa-facebook-f"></i>'.esc_html__('Facebook', 'indusri-pro').'</a>';
								}
								if($enable_google_login) {
									$out .= '<a href="'.indusri_pro_google_login_url().'" class="indusri-pro-social-google-connect"><i class="fab fa-google"></i>'.esc_html__('Google', 'indusri-pro').'</a>';
								}
	
							$out .= '</div>';
	
						}
					}
					$out .= '</div>';

				$out .= '</div>';

			$out .= '</div>';

			$out .= '<div class="indusri-pro-login-form-overlay"></div>';

			return $out;

		}
	}

	/* ---------------------------------------------------------------------------
	* Google login utils
	* --------------------------------------------------------------------------- */

	if( !function_exists( 'indusri_pro_google_login_url' ) ) {
		function indusri_pro_google_login_url() {
			return site_url('wp-login.php') . '?dtLMSGoogleLogin=1';
		}
	}

	function indusri_pro_google_login() {

		$dtLMSGoogleLogin = isset($_REQUEST['dtLMSGoogleLogin']) ? indusri_sanitization($_REQUEST['dtLMSGoogleLogin']) : '';
		if ($dtLMSGoogleLogin == '1') {
			indusri_pro_google_login_action();
		}
	
	}
	add_action('login_init', 'indusri_pro_google_login');

	if( !function_exists('indusri_pro_google_login_action') ) {
		function indusri_pro_google_login_action() {

			require_once INDUSRI_PRO_DIR_URL.'modules/auth/apis/google/Google_Client.php';
			require_once INDUSRI_PRO_DIR_URL.'modules/auth/apis/google/contrib/Google_Oauth2Service.php';
			
			$google_client_id = (indusri_customizer_settings( 'google_client_id' ) !== null) && !empty(indusri_customizer_settings( 'google_client_id' )) ? indusri_customizer_settings( 'google_client_id' ) : '';
			$google_client_secret = (indusri_customizer_settings( 'google_client_secret' ) !== null) && !empty(indusri_customizer_settings( 'google_client_secret' )) ? indusri_customizer_settings( 'google_client_secret' ) : '';

			$clientId     = $google_client_id; //Google CLIENT ID
			$clientSecret = $google_client_secret; //Google CLIENT SECRET
			$redirectUrl  = indusri_pro_google_login_url();  //return url (url to script)
		
			$gClient = new Google_Client();
			$gClient->setApplicationName(esc_html__('Login To Website', 'indusri-pro'));
			$gClient->setClientId($clientId);
			$gClient->setClientSecret($clientSecret);
			$gClient->setRedirectUri($redirectUrl);
		
			$google_oauthV2 = new Google_Oauth2Service($gClient);
		
			if(isset($google_oauthV2)){
		
				$gClient->authenticate();
				$_SESSION['token'] = $gClient->getAccessToken();
		
				if (isset($_SESSION['token'])) {
					$gClient->setAccessToken($_SESSION['token']);
				}
		
				$user_profile = $google_oauthV2->userinfo->get();
		
				$args = array(
					'meta_key'     => 'google_id',
					'meta_value'   => $user_profile['id'],
					'meta_compare' => '=',
				 );
				$users = get_users( $args );
		
				if(is_array($users) && !empty($users)) {
					$ID = $users[0]->data->ID;
				} else {
					$ID = NULL;
				}
		
				if ($ID == NULL) {
		
					if (!isset($user_profile['email'])) {
						$user_profile['email'] = $user_profile['id'] . '@gmail.com';
					}
		
					$random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
		
					$username = strtolower($user_profile['name']);
					$username = trim(str_replace(' ', '', $username));
		
					$sanitized_user_login = sanitize_user('google-'.$username);
		
					if (!validate_username($sanitized_user_login)) {
						$sanitized_user_login = sanitize_user('google-' . $user_profile['id']);
					}
		
					$defaul_user_name = $sanitized_user_login;
					$i = 1;
					while (username_exists($sanitized_user_login)) {
					  $sanitized_user_login = $defaul_user_name . $i;
					  $i++;
					}
		
					$ID = wp_create_user($sanitized_user_login, $random_password, $user_profile['email']);
		
					if (!is_wp_error($ID)) {
		
						wp_new_user_notification($ID, $random_password);
						$user_info = get_userdata($ID);
						wp_update_user(array(
							'ID' => $ID,
							'display_name' => $user_profile['name'],
							'first_name' => $user_profile['name'],
						));
		
						update_user_meta($ID, 'google_id', $user_profile['id']);
		
					}
		
				}
		
				// Login
				if ($ID) {
		
				  $secure_cookie = is_ssl();
				  $secure_cookie = apply_filters('secure_signon_cookie', $secure_cookie, array());
				  global $auth_secure_cookie;
		
				  $auth_secure_cookie = $secure_cookie;
				  wp_set_auth_cookie($ID, false, $secure_cookie);
				  $user_info = get_userdata($ID);
				  update_user_meta($ID, 'google_profile_picture', $user_profile['picture']);
				  do_action('wp_login', $user_info->user_login, $user_info, 10, 2);
				  update_user_meta($ID, 'google_user_access_token', $_SESSION['token']);
		
				//   wp_redirect(indusri_pro_get_login_redirect_url($user_info));
				wp_redirect(home_url());
		
				}
		
			} else {
		
				$authUrl = $gClient->createAuthUrl();
				header('Location: ' . $authUrl);
				exit;
		
			}
		
		}
	}

	/* if( !function_exists( 'indusri_pro_get_login_redirect_url' ) ) {
		function indusri_pro_get_login_redirect_url($user_info) {

			$dtlms_redirect_url = '';
			if(isset($user_info->data->ID)) {
				$current_user = $user_info;

			}

		}
	} */

}

IndusriProAuth::instance();