<?php

/**
 * Listings - Shop
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Indusri_Shop_Listing_Shop' ) ) {

    class Indusri_Shop_Listing_Shop {

        private static $_instance = null;

        private $settings;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            /* Load Modules */
                $this->load_modules();

        }

        /*
        Load Modules
        */
            function load_modules() {

                /* Customizer */
                    include_once INDUSRI_SHOP_PATH . 'modules/shop/customizer/index.php';

            }

    }

}


if( !function_exists('indusri_shop_listing_shop') ) {
	function indusri_shop_listing_shop() {
		return Indusri_Shop_Listing_Shop::instance();
	}
}

indusri_shop_listing_shop();