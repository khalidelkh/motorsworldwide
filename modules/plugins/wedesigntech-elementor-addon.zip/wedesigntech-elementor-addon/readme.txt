===== WeDesignTech Elementor Addon =====

WeDesignTech Elementor Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.1 =

    * Compatible :Latest Elementor version

= 1.0.0 =

    * First release!