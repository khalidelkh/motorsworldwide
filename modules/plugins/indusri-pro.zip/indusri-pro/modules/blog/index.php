<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'IndusriProSiteBlog' ) ) {
    class IndusriProSiteBlog extends IndusriPlusSiteBlog {

        private static $_instance = null;
        public $element_position = array();

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            $this->load_widgets();
            add_action( 'indusri_after_main_css', array( $this, 'enqueue_css_assets' ), 20 );
            add_filter('blog_post_grid_list_style_update', array( $this, 'blog_post_grid_list_style_update' ));
            add_filter('blog_post_cover_style_update', array( $this, 'blog_post_cover_style_update' ));
        }

        function enqueue_css_assets() {
            wp_enqueue_style( 'indusri-pro-blog', INDUSRI_PRO_DIR_URL . 'modules/blog/assets/css/blog.css', false, INDUSRI_PRO_VERSION, 'all');

            $post_style = indusri_get_archive_post_style();
            $file_path = INDUSRI_PRO_DIR_PATH . 'modules/blog/templates/'.esc_attr($post_style).'/assets/css/blog-archive-'.esc_attr($post_style).'.css';
            if ( file_exists( $file_path ) ) {
                wp_enqueue_style( 'wdt-blog-archive-'.esc_attr($post_style), INDUSRI_PRO_DIR_URL . 'modules/blog/templates/'.esc_attr($post_style).'/assets/css/blog-archive-'.esc_attr($post_style).'.css', false, INDUSRI_PRO_VERSION, 'all');
            }

        }

        function load_widgets() {
            add_action( 'widgets_init', array( $this, 'register_widgets_init' ) );
        }

        function register_widgets_init() {
            include_once INDUSRI_PRO_DIR_PATH.'modules/blog/widget/widget-recent-posts.php';
            register_widget('Indusri_Widget_Recent_Posts');
        }

        function blog_post_grid_list_style_update($list) {

            $pro_list = array (
                'wdt-simple'        => esc_html__('Simple', 'indusri-pro'),
                'wdt-overlap'       => esc_html__('Overlap', 'indusri-pro'),
                'wdt-thumb-overlap' => esc_html__('Thumb Overlap', 'indusri-pro'),
                'wdt-minimal'       => esc_html__('Minimal', 'indusri-pro'),
                'wdt-fancy-box'     => esc_html__('Fancy Box', 'indusri-pro'),
                'wdt-bordered'      => esc_html__('Bordered', 'indusri-pro'),
                'wdt-magnificent'   => esc_html__('Magnificent', 'indusri-pro')
            );

            return array_merge( $list, $pro_list );

        }

        function blog_post_cover_style_update($list) {

            $pro_list = array ();
            return array_merge( $list, $pro_list );

        }

    }
}

IndusriProSiteBlog::instance();

if( !class_exists( 'IndusriProSiteRelatedBlog' ) ) {
    class IndusriProSiteRelatedBlog extends IndusriProSiteBlog {
        function __construct() {}
    }
}