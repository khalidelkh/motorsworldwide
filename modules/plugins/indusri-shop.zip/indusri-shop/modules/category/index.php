<?php

/**
 * Listings - Category
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Indusri_Shop_Listing_Category' ) ) {

    class Indusri_Shop_Listing_Category {

        private static $_instance = null;

        private $settings;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            /* Load Modules */
                $this->load_modules();

        }

        /*
        Load Modules
        */
            function load_modules() {

                /* Customizer */
                    include_once INDUSRI_SHOP_PATH . 'modules/category/customizer/index.php';

            }

    }

}


if( !function_exists('indusri_shop_listing_category') ) {
	function indusri_shop_listing_category() {
		return Indusri_Shop_Listing_Category::instance();
	}
}

indusri_shop_listing_category();