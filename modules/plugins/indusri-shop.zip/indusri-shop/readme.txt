===== Indusri Shop =====

Indusri Shop plugin adds shop features for Indusri theme.


== Changelog ==

= 1.0.0 =

    * First release!